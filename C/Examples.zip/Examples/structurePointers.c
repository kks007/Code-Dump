#include <stdio.h>

struct date 
{
    int month;
    int day;
    int year;
};



int main()
{

}