#include <stdio.h>

int main()
{

    int values [100];
    int *valuesPtr;
    valuesPtr = values;

    /*
    method 2:
    int values[100]; 
    valuesPtr = &values[0];
    */
    
    

}